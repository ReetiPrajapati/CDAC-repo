
package com.example.swh_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SwhBackApplication {


    public static void main(String[] args) {
        SpringApplication.run(SwhBackApplication.class, args);
    }

}




